import mysql.connector

if __name__ == '__main__':
    # connect to the server
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the statements
    cursor = mydb.cursor()
    statements = [
        # (a) before: rows that reference the Data department
        """
        SELECT 'employee', emp_id, dept_id FROM employee WHERE dept_id = 5
        UNION ALL
        SELECT 'project', project_id, dept_id FROM project WHERE dept_id = 5
        """,
        # (a) the Data department gets id 50
        """
        UPDATE department
        SET dept_id = 50
        WHERE name = 'Data' 
        """,
        # Answer: employees 6, 17, 18 and projects 4, 9 now have dept_id 50.
        # Both employee.dept_id and project.dept_id were created with ON UPDATE CASCADE,
        # so the new id was copied into the child rows and nothing failed.
        # (a) after: the same rows now point to 50
        """
        SELECT 'employee', emp_id, dept_id FROM employee WHERE dept_id = 50
        UNION ALL
        SELECT 'project', project_id, dept_id FROM project WHERE dept_id = 50
        """,
        # (b) before: rows that depend on Lisbon Media
        """
        SELECT 'project', project_id, customer_id FROM project WHERE customer_id = 6
        UNION ALL
        SELECT 'assignment', emp_id, project_id FROM assignment WHERE project_id = 8
        UNION ALL
        SELECT 'api_usage', usage_id, customer_id FROM api_usage WHERE customer_id = 6
        """,
        # (b) delete the customer Lisbon Media
        """
        DELETE FROM customer
        WHERE company_name = 'Lisbon Media' 
        """,
        # Answer: the customer row is gone, project 8 (Newsroom Copilot) is deleted
        # and its assignments (employees 14 and 10) are deleted too,
        # and both api_usage rows of the customer are deleted.
        # Policy: project.customer_id and api_usage.customer_id are ON DELETE CASCADE,
        # and assignment.project_id is ON DELETE CASCADE, so the delete moves down two levels.
        # (b) after: nothing is left for Lisbon Media
        """
        SELECT 'project', project_id, customer_id FROM project WHERE customer_id = 6
        UNION ALL
        SELECT 'assignment', emp_id, project_id FROM assignment WHERE project_id = 8
        UNION ALL
        SELECT 'api_usage', usage_id, customer_id FROM api_usage WHERE customer_id = 6
        """,
        # (c) before: rows that reference employee 17
        """
        SELECT 'ai_model', model_id, lead_engineer_id FROM ai_model WHERE lead_engineer_id = 17
        UNION ALL
        SELECT 'employee', emp_id, manager_id FROM employee WHERE manager_id = 17
        UNION ALL
        SELECT 'assignment', emp_id, project_id FROM assignment WHERE emp_id = 17
        """,
        # (c) employee 18 replaces employee 17 as lead engineer of BarEmbed
        """
        UPDATE ai_model
        SET lead_engineer_id = 18
        WHERE model_name = 'BarEmbed' 
        """,
        # Answer: this update must come first. ai_model.lead_engineer_id has no ON DELETE policy,
        # so the default RESTRICT would reject the delete of employee 17 while BarEmbed points to it.
        # (c) delete employee 17
        """
        DELETE FROM employee
        WHERE emp_id = 17
        """,
        # Answer: the employee row is gone, the manager_id of employee 18 became NULL
        # (employee.manager_id is ON DELETE SET NULL), and the assignments of employee 17
        # in projects 4 and 9 are deleted (assignment.emp_id is ON DELETE CASCADE).
        # (c) after: the references to employee 17 are gone
        """
        SELECT 'ai_model', model_id, lead_engineer_id FROM ai_model WHERE model_name = 'BarEmbed'
        UNION ALL
        SELECT 'employee', emp_id, manager_id FROM employee WHERE emp_id = 18
        UNION ALL
        SELECT 'assignment', emp_id, project_id FROM assignment WHERE emp_id = 17
        """,
        # (d) delete the Haifa office - this statement FAILS, so it is commented out:
        # DELETE FROM office WHERE city = 'Haifa'
        # Answer: error 1451, the department Data (office_id 3) still points to the Haifa office.
        # department.office_id was created with the default policy RESTRICT, which rejects the delete.
        # ON DELETE SET NULL would not work here: office_id is NOT NULL, so it can not become NULL
        # (MySQL even refuses to create such a foreign key on a NOT NULL column).
        # (e) before: the usage rows older than 2026-07-10
        """
        SELECT usage_id, customer_id, usage_date FROM api_usage WHERE usage_date < '2026-07-10' 
        """,
        # (e) delete the archived usage records
        """
        DELETE FROM api_usage
        WHERE usage_date < '2026-07-10' 
        """,
        # Answer: only api_usage changed (3 rows deleted). No other table changed,
        # because api_usage is a child table - no table has a foreign key that points to it.
        # (e) after: no old usage rows are left
        """
        SELECT COUNT(*) FROM api_usage WHERE usage_date < '2026-07-10' 
        """,
        # (f) delete the Research department - this statement FAILS, so it is commented out:
        # DELETE FROM department WHERE name = 'Research'
        # Answer: error 1451, projects 1, 7, 10 are owned by Research and project.dept_id is ON DELETE RESTRICT.
        # The whole statement is cancelled, so the employee.dept_id SET NULL policy does nothing either.
        # (g) delete the model BarGPT-1 - this statement FAILS, so it is commented out:
        # DELETE FROM ai_model WHERE model_name = 'BarGPT-1'
        # Answer: error 1451, api_usage.model_id is ON DELETE RESTRICT and usage rows of model 1 still exist.
        # Project 3 did not change: it still has model_id 1. project.model_id is ON DELETE SET NULL,
        # but that policy only runs when the delete succeeds, and RESTRICT cancelled the whole statement.
        # To make it work, the usage rows of the model would have to be deleted first.
        # (h) change the id of Yam Bank from 3 to 30 - this statement FAILS, so it is commented out:
        # UPDATE customer SET customer_id = 30 WHERE company_name = 'Yam Bank'
        # Answer: error 1451, projects 4, 5 and rows of api_usage still point to customer 3.
        # The foreign keys of project and api_usage define only ON DELETE CASCADE, so ON UPDATE is the default RESTRICT.
        # Compared with (a): there the foreign keys had ON UPDATE CASCADE, so the new id was copied and the update worked.
        # (i) assign employee 99 to project 1 - this statement FAILS, so it is commented out:
        # INSERT INTO assignment (emp_id, project_id, role) VALUES (99, 1, 'Researcher')
        # Answer: error 1452, employee 99 does not exist, and assignment.emp_id is a foreign key to employee.
        # A child row can not point to a parent row that is missing.
    ]
    # run every statement in order and print rows when there are any
    for statement in statements:
        cursor.execute(statement)
        if cursor.with_rows:
            print(cursor.fetchall())
    # save the changes and close
    mydb.commit()
    cursor.close()
    mydb.close()
