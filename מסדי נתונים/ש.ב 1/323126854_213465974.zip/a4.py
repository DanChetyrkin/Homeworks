import mysql.connector

if __name__ == '__main__':
    # connect to the server
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the statements
    cursor = mydb.cursor()
    statements = [
        # (a) office table
        """
        CREATE TABLE office (
            office_id INT PRIMARY KEY,
            city VARCHAR(50) NOT NULL,
            country VARCHAR(50) NOT NULL DEFAULT 'Israel',
            capacity INT NOT NULL CHECK (capacity > 0)
        )
        """,
        # (a) load the offices
        """
        INSERT INTO office (office_id, city, country, capacity) VALUES
            (1, 'Ramat Gan', 'Israel', 250),
            (2, 'Tel Aviv', 'Israel', 120),
            (3, 'Haifa', 'Israel', 80),
            (4, 'Berlin', 'Germany', 40)
        """,
        # (b)(i) new office_id column right after name
        """
        ALTER TABLE department
        ADD office_id INT NOT NULL AFTER name
        """,
        # (b)(ii) fill office_id from the department location, no hard-coded ids
        """
        UPDATE department
        SET office_id = (SELECT office.office_id
                         FROM office
                         WHERE office.city = department.location)
        """,
        # (b)(iii) foreign key from department to office
        """
        ALTER TABLE department
        ADD FOREIGN KEY (office_id) REFERENCES office(office_id)
        """,
        # (b)(iv) location is not needed anymore
        """
        ALTER TABLE department
        DROP location
        """,
        # (c)(i) tier column at the end of customer
        """
        ALTER TABLE customer
        ADD tier VARCHAR(10) NOT NULL DEFAULT 'Basic' 
        """,
        # Answer: all 10 existing customers are 'Basic', because the column is NOT NULL
        # and every existing row gets the DEFAULT value when a column is added.
        # (c)(ii) tier must be one of the three allowed values
        """
        ALTER TABLE customer
        ADD CHECK (tier IN ('Basic', 'Pro', 'Enterprise'))
        """,
        # (c)(iii) account manager column at the end of customer
        """
        ALTER TABLE customer
        ADD account_manager_id INT
        """,
        # (c)(iii) foreign key from account manager to employee
        """
        ALTER TABLE customer
        ADD FOREIGN KEY (account_manager_id) REFERENCES employee(emp_id)
            ON DELETE SET NULL
        """,
        # (d) longer model names
        """
        ALTER TABLE ai_model
        MODIFY model_name VARCHAR(60) NOT NULL
        """,
        # Answer: 'BarGPT-3 Reasoning Ultra' has 24 characters and the old limit was 20,
        # so the insert would fail with 'Data too long for column' (strict mode),
        # or the name would be silently cut to 20 characters (non strict mode).
        # MODIFY repeats NOT NULL, otherwise the NOT NULL would be lost.
        # (e) rename salary
        """
        ALTER TABLE employee
        RENAME COLUMN salary TO monthly_salary
        """,
        # (e) salary must be positive
        """
        ALTER TABLE employee
        ADD CHECK (monthly_salary > 0)
        """,
        # (f) api_usage table, usage_id is filled by AUTO_INCREMENT
        """
        CREATE TABLE api_usage (
            usage_id INT UNIQUE AUTO_INCREMENT,
            customer_id INT NOT NULL,
            model_id INT NOT NULL,
            usage_date DATE NOT NULL,
            tokens INT NOT NULL CHECK (tokens > 0),
            PRIMARY KEY (customer_id, model_id, usage_date),
            FOREIGN KEY (customer_id) REFERENCES customer(customer_id)
                ON DELETE CASCADE,
            FOREIGN KEY (model_id) REFERENCES ai_model(model_id)
                ON DELETE RESTRICT
        )
        """,
        # (f) load the usage rows without usage_id
        """
        INSERT INTO api_usage (customer_id, model_id, usage_date, tokens) VALUES
            (1, 2, '2026-07-01', 120000),
            (1, 3, '2026-07-15', 80000),
            (1, 2, '2026-08-01', 150000),
            (1, 3, '2026-09-01', 95000),
            (1, 2, '2026-10-01', 90000),
            (2, 1, '2026-07-03', 40000),
            (2, 4, '2026-08-03', 60000),
            (2, 4, '2026-09-03', 75000),
            (2, 1, '2026-10-03', 30000),
            (3, 2, '2026-07-05', 300000),
            (3, 4, '2026-07-20', 110000),
            (3, 2, '2026-08-05', 280000),
            (3, 6, '2026-09-05', 200000),
            (3, 2, '2026-10-05', 320000),
            (4, 3, '2026-07-10', 50000),
            (4, 3, '2026-08-10', 65000),
            (4, 5, '2026-09-10', 500000),
            (5, 3, '2026-08-12', 20000),
            (6, 6, '2026-09-15', 150000),
            (6, 6, '2026-10-15', 180000),
            (7, 5, '2026-07-20', 900000),
            (7, 5, '2026-08-20', 1100000),
            (7, 1, '2026-09-20', 10000),
            (8, 6, '2026-10-01', 60000),
            (8, 4, '2026-10-20', 25000),
            (9, 1, '2026-10-25', 5000)
        """,
    ]
    # run every statement in order and print rows when there are any
    for statement in statements:
        cursor.execute(statement)
        if cursor.with_rows:
            print(cursor.fetchall())
    # save the changes and close
    mydb.commit()
    cursor.close()
    mydb.close()
