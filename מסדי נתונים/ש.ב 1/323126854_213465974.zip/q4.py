import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: window AVG per department keeps one row per employee
    cursor.execute("""
         SELECT tiger.emp_id,
                tiger.first_name,
                tiger.last_name,
                donut.name AS department,
                tiger.monthly_salary,
                AVG(tiger.monthly_salary) OVER (PARTITION BY tiger.dept_id) AS dept_avg_salary,
                tiger.monthly_salary - AVG(tiger.monthly_salary) OVER (PARTITION BY tiger.dept_id) AS diff_from_avg
         FROM employee AS tiger
         JOIN department AS donut ON tiger.dept_id = donut.dept_id
         ORDER BY donut.name, tiger.monthly_salary DESC, tiger.emp_id
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
