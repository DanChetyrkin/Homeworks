import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: window AVG per department keeps one row per employee
    cursor.execute("""
         SELECT worker_bee.emp_id,
                worker_bee.first_name,
                worker_bee.last_name,
                dept_den.name AS department,
                worker_bee.monthly_salary,
                AVG(worker_bee.monthly_salary) OVER (PARTITION BY worker_bee.dept_id) AS dept_avg_salary,
                worker_bee.monthly_salary - AVG(worker_bee.monthly_salary) OVER (PARTITION BY worker_bee.dept_id) AS diff_from_avg
         FROM employee AS worker_bee
         JOIN department AS dept_den ON worker_bee.dept_id = dept_den.dept_id
         ORDER BY dept_den.name, worker_bee.monthly_salary DESC, worker_bee.emp_id
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
