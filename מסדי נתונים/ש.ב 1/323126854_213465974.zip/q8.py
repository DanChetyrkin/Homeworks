import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: NOT EXISTS an ongoing project (no end date) for the employee,
    # employees with no assignment at all pass as well
    cursor.execute("""
         SELECT worker_bee.emp_id, worker_bee.first_name, worker_bee.last_name
         FROM employee AS worker_bee
         WHERE NOT EXISTS (
             SELECT *
             FROM assignment AS gig_slip
             JOIN project AS grand_plan ON gig_slip.project_id = grand_plan.project_id
             WHERE gig_slip.emp_id = worker_bee.emp_id
               AND grand_plan.end_date IS NULL
         )
         ORDER BY worker_bee.emp_id
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
