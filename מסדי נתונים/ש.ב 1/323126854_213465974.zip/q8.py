import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: NOT EXISTS an ongoing project (no end date) for the employee,
    # employees with no assignment at all pass as well
    cursor.execute("""
         SELECT sloth.emp_id, sloth.first_name, sloth.last_name
         FROM employee AS sloth
         WHERE NOT EXISTS (
             SELECT *
             FROM assignment AS noodle
             JOIN project AS waffle ON noodle.project_id = waffle.project_id
             WHERE noodle.emp_id = sloth.emp_id
               AND waffle.end_date IS NULL
         )
         ORDER BY sloth.emp_id
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
