import mysql.connector

if __name__ == '__main__':
    # connect to the server
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the statements
    cursor = mydb.cursor()
    statements = [
        # (a) view of the ongoing projects (no end date)
        """
        CREATE VIEW ongoing_projects AS
        SELECT grand_plan.project_id,
               grand_plan.project_name,
               paying_pal.company_name,
               dept_den.name AS department
        FROM project AS grand_plan
        JOIN customer AS paying_pal ON grand_plan.customer_id = paying_pal.customer_id
        JOIN department AS dept_den ON grand_plan.dept_id = dept_den.dept_id
        WHERE grand_plan.end_date IS NULL
        """,
        # (b) show all rows of the view
        """
        SELECT * FROM ongoing_projects
        """,
    ]
    # run every statement in order and print rows when there are any
    for statement in statements:
        cursor.execute(statement)
        if cursor.with_rows:
            print(cursor.fetchall())
    # save the changes and close
    mydb.commit()
    cursor.close()
    mydb.close()
