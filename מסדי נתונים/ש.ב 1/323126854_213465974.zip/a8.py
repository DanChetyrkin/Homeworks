import mysql.connector

if __name__ == '__main__':
    # connect to the server
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the statements
    cursor = mydb.cursor()
    statements = [
        # (a) view of the ongoing projects (no end date)
        """
        CREATE VIEW ongoing_projects AS
        SELECT waffle.project_id,
               waffle.project_name,
               pickle.company_name,
               donut.name AS department
        FROM project AS waffle
        JOIN customer AS pickle ON waffle.customer_id = pickle.customer_id
        JOIN department AS donut ON waffle.dept_id = donut.dept_id
        WHERE waffle.end_date IS NULL
        """,
        # (b) show all rows of the view
        """
        SELECT * FROM ongoing_projects
        """,
    ]
    # run every statement in order and print rows when there are any
    for statement in statements:
        cursor.execute(statement)
        if cursor.with_rows:
            print(cursor.fetchall())
    # save the changes and close
    mydb.commit()
    cursor.close()
    mydb.close()
