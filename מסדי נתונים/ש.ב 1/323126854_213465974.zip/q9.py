import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: EXISTS a usage of an LLM model and NOT EXISTS a usage of a Vision model
    cursor.execute("""
         SELECT pickle.customer_id, pickle.company_name
         FROM customer AS pickle
         WHERE EXISTS (
             SELECT *
             FROM api_usage AS zebra
             JOIN ai_model AS llama ON zebra.model_id = llama.model_id
             WHERE zebra.customer_id = pickle.customer_id
               AND llama.model_type = 'LLM'
         )
         AND NOT EXISTS (
             SELECT *
             FROM api_usage AS zebra
             JOIN ai_model AS llama ON zebra.model_id = llama.model_id
             WHERE zebra.customer_id = pickle.customer_id
               AND llama.model_type = 'Vision'
         )
         ORDER BY pickle.customer_id
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
