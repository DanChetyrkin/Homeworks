import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: EXISTS a usage of an LLM model and NOT EXISTS a usage of a Vision model
    cursor.execute("""
         SELECT paying_pal.customer_id, paying_pal.company_name
         FROM customer AS paying_pal
         WHERE EXISTS (
             SELECT *
             FROM api_usage AS token_munch
             JOIN ai_model AS brainy_bot ON token_munch.model_id = brainy_bot.model_id
             WHERE token_munch.customer_id = paying_pal.customer_id
               AND brainy_bot.model_type = 'LLM'
         )
         AND NOT EXISTS (
             SELECT *
             FROM api_usage AS token_munch
             JOIN ai_model AS brainy_bot ON token_munch.model_id = brainy_bot.model_id
             WHERE token_munch.customer_id = paying_pal.customer_id
               AND brainy_bot.model_type = 'Vision'
         )
         ORDER BY paying_pal.customer_id
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
