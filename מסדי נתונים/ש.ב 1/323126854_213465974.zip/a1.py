import mysql.connector

if __name__ == '__main__':
    # connect to the server
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        port="3307",
    )

    # cursor that runs the statements
    cursor = mydb.cursor()
    statements = [
        # (a) create the bar_ai database
        """
        CREATE DATABASE bar_ai
        """,
    ]
    # run every statement in order and print rows when there are any
    for statement in statements:
        cursor.execute(statement)
        if cursor.with_rows:
            print(cursor.fetchall())
    # save the changes and close
    mydb.commit()
    cursor.close()
    mydb.close()
