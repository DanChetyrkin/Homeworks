import mysql.connector

if __name__ == '__main__':
    # connect to the server
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the statements
    cursor = mydb.cursor()
    statements = [
        # (a) load the departments
        """
        INSERT INTO department (dept_id, name, budget, location) VALUES
            (1, 'Research', 2500000, 'Ramat Gan'),
            (2, 'Engineering', 3000000, 'Ramat Gan'),
            (3, 'Product', 900000, 'Tel Aviv'),
            (4, 'Sales', 1200000, 'Tel Aviv'),
            (5, 'Data', 1100000, 'Haifa'),
            (6, 'HR', 400000, 'Ramat Gan')
        """,
        # (b) load the employees (managers come before their workers)
        """
        INSERT INTO employee (emp_id, first_name, last_name, email, hire_date, salary, dept_id, manager_id) VALUES
            (1, 'Noa', 'Bar', 'noa.bar@bar-ai.com', '2021-01-03', 60000, NULL, NULL),
            (2, 'Yonatan', 'Levi', 'yonatan.levi@bar-ai.com', '2021-02-01', 42000, 1, 1),
            (3, 'Maya', 'Cohen', 'maya.cohen@bar-ai.com', '2021-02-15', 40000, 2, 1),
            (4, 'Daniel', 'Mizrahi', 'daniel.mizrahi@bar-ai.com', '2021-09-01', 32000, 3, 1),
            (5, 'Shira', 'Peretz', 'shira.peretz@bar-ai.com', '2022-01-10', 30000, 4, 1),
            (6, 'Omer', 'Friedman', 'omer.friedman@bar-ai.com', '2022-03-01', 31000, 5, 1),
            (7, 'Tamar', 'Azoulay', 'tamar.azoulay@bar-ai.com', '2022-05-01', 22000, 6, 1),
            (8, 'Itai', 'Shapiro', 'itai.shapiro@bar-ai.com', '2022-06-12', 28000, 1, 2),
            (9, 'Lior', 'Katz', 'lior.katz@bar-ai.com', '2022-08-01', 26000, 1, 2),
            (10, 'Yael', 'Ben-David', 'yael.ben-david@bar-ai.com', '2023-01-08', 26000, 1, 2),
            (11, 'Amit', 'Golan', 'amit.golan@bar-ai.com', '2022-04-03', 24000, 2, 3),
            (12, 'Roni', 'Dahan', 'roni.dahan@bar-ai.com', '2023-03-19', 21000, 2, 3),
            (13, 'Eden', 'Malka', 'eden.malka@bar-ai.com', '2025-07-01', 14500, 2, 3),
            (14, 'Gal', 'Avraham', 'gal.avraham@bar-ai.com', '2023-10-01', 18000, 3, 4),
            (15, 'Neta', 'Klein', 'neta.klein@bar-ai.com', '2022-11-20', 16000, 4, 5),
            (16, 'Ido', 'Rosen', 'ido.rosen@bar-ai.com', '2025-02-02', 12500, 4, 5),
            (17, 'Hila', 'Weiss', 'hila.weiss@bar-ai.com', '2022-09-04', 19000, 5, 6),
            (18, 'Tom', 'Segal', 'tom.segal@bar-ai.com', '2024-12-01', 13000, 5, 17),
            (19, 'Michal', 'Oren', 'michal.oren@bar-ai.com', '2023-06-25', 24000, 2, 3),
            (20, 'Ariel', 'Nachum', 'ariel.nachum@bar-ai.com', '2025-03-16', 15000, 1, 8)
        """,
        # (c) load the customers (missing industry is a real NULL)
        """
        INSERT INTO customer (customer_id, company_name, country, industry, joined_date) VALUES
            (1, 'Galil Health', 'Israel', 'Healthcare', '2022-02-10'),
            (2, 'Negev Logistics', 'Israel', 'Logistics', '2022-06-01'),
            (3, 'Yam Bank', 'Israel', 'Finance', '2023-01-15'),
            (4, 'Nordic Freight', 'Sweden', 'Logistics', '2023-04-20'),
            (5, 'Andes Mining', 'Chile', NULL, '2023-09-05'),
            (6, 'Lisbon Media', 'Portugal', 'Media', '2024-03-12'),
            (7, 'Kineret Retail', 'Israel', 'Retail', '2024-07-30'),
            (8, 'Maple Learning', 'Canada', 'Education', '2025-01-08'),
            (9, 'Danube Pharma', 'Austria', NULL, '2025-05-19'),
            (10, 'Sahara Solar', 'Morocco', 'Energy', '2025-10-02')
        """,
        # (d) load the model types
        """
        INSERT INTO model_type (type_name, description) VALUES
            ('LLM', 'Large language model - text in, text out'),
            ('Vision', 'Image and video understanding'),
            ('Speech', 'Speech recognition and speech generation'),
            ('Embedding', 'Turns text into vectors, for search and retrieval')
        """,
        # (e) load the models
        """
        INSERT INTO ai_model (model_id, model_name, model_type, release_date, price_per_1k_tokens, lead_engineer_id) VALUES
            (1, 'BarGPT-1', 'LLM', '2022-01-10', 0.0200, 2),
            (2, 'BarGPT-2', 'LLM', '2023-05-01', 0.0300, 8),
            (3, 'BarVision', 'Vision', '2023-11-20', 0.0450, 11),
            (4, 'BarVoice', 'Speech', '2024-06-15', 0.0150, 9),
            (5, 'BarEmbed', 'Embedding', '2024-09-01', 0.0040, 17),
            (6, 'BarGPT-3', 'LLM', '2025-08-10', 0.0500, 10),
            (7, 'BarVision-Lite', 'Vision', NULL, 0.0250, NULL)
        """,
        # (f) load the projects
        """
        INSERT INTO project (project_id, project_name, customer_id, dept_id, model_id, start_date, end_date, budget) VALUES
            (1, 'Clinical Notes Summarizer', 1, 1, 2, '2023-03-01', '2023-12-31', 450000),
            (2, 'X-Ray Triage', 1, 2, 3, '2024-01-15', NULL, 800000),
            (3, 'Route Optimizer Chatbot', 2, 2, 1, '2022-09-01', '2023-06-30', 300000),
            (4, 'Fraud Detection Assistant', 3, 5, 2, '2023-06-01', NULL, 950000),
            (5, 'Voice Banking', 3, 3, 4, '2024-08-01', '2025-07-31', 400000),
            (6, 'Shipment Document Reader', 4, 2, 3, '2024-02-01', NULL, 600000),
            (7, 'Ore Image Analysis', 5, 1, 3, '2024-05-10', '2025-03-01', 350000),
            (8, 'Newsroom Copilot', 6, 3, 6, '2025-09-01', NULL, 500000),
            (9, 'Smart Product Search', 7, 5, 5, '2025-02-01', NULL, 250000),
            (10, 'Tutor Bot', 8, 1, 6, '2025-10-01', NULL, 700000),
            (11, 'Call Center Insights', 2, 3, 4, '2025-04-01', NULL, 200000)
        """,
        # (g) load the assignments
        """
        INSERT INTO assignment (emp_id, project_id, role, hours_per_week) VALUES
            (2, 1, 'Tech Lead', 10),
            (8, 1, 'Researcher', 30),
            (9, 1, 'Researcher', 20),
            (3, 2, 'Tech Lead', 8),
            (11, 2, 'ML Engineer', 35),
            (19, 2, 'ML Engineer', 30),
            (13, 2, 'Backend Developer', 40),
            (12, 3, 'Backend Developer', 25),
            (11, 3, 'ML Engineer', 10),
            (6, 4, 'Tech Lead', 10),
            (17, 4, 'Data Scientist', 35),
            (18, 4, 'Data Engineer', 30),
            (4, 5, 'Product Manager', 15),
            (9, 5, 'Researcher', 15),
            (14, 5, 'Product Manager', 25),
            (12, 6, 'Backend Developer', 15),
            (19, 6, 'ML Engineer', 10),
            (10, 7, 'Researcher', 30),
            (20, 7, 'Research Assistant', 20),
            (14, 8, 'Product Manager', 20),
            (10, 8, 'Researcher', 10),
            (17, 9, 'Data Scientist', 5),
            (18, 9, 'Data Engineer', 10),
            (10, 10, 'Researcher', 20),
            (8, 10, 'Tech Lead', 10),
            (20, 10, 'Research Assistant', 20),
            (15, 11, 'Account Executive', 10),
            (14, 11, 'Product Manager', 10)
        """,
    ]
    # run every statement in order and print rows when there are any
    for statement in statements:
        cursor.execute(statement)
        if cursor.with_rows:
            print(cursor.fetchall())
    # save the changes and close
    mydb.commit()
    cursor.close()
    mydb.close()
