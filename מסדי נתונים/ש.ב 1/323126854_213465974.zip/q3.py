import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: CASE WHEN gives every employee a level, then group by the level
    cursor.execute("""
         WITH salary_bands AS (
             SELECT monthly_salary,
                    CASE
                        WHEN monthly_salary < 15000 THEN 'Junior'
                        WHEN monthly_salary BETWEEN 15000 AND 25000 THEN 'Mid'
                        ELSE 'Senior'
                    END AS salary_level
             FROM employee
         )
         SELECT salary_level,
                COUNT(*) AS num_employees,
                AVG(monthly_salary) AS avg_salary
         FROM salary_bands
         GROUP BY salary_level
         ORDER BY avg_salary DESC
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
