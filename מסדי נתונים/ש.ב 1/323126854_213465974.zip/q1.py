import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: every employee with department and manager, outer joins keep the missing ones,
    # COALESCE gives the default texts
    cursor.execute("""
         SELECT pancake.emp_id,
                CONCAT(pancake.first_name, ' ', pancake.last_name) AS employee_name,
                COALESCE(donut.name, 'No Department') AS department,
                COALESCE(CONCAT(muffin.first_name, ' ', muffin.last_name), 'No Manager') AS manager_name
         FROM employee AS pancake
         LEFT JOIN department AS donut ON pancake.dept_id = donut.dept_id
         LEFT JOIN employee AS muffin ON pancake.manager_id = muffin.emp_id
         ORDER BY pancake.emp_id
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
