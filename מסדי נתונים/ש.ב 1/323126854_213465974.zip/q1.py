import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: every employee with department and manager, outer joins keep the missing ones,
    # COALESCE gives the default texts
    cursor.execute("""
         SELECT worker_bee.emp_id,
                CONCAT(worker_bee.first_name, ' ', worker_bee.last_name) AS employee_name,
                COALESCE(dept_den.name, 'No Department') AS department,
                COALESCE(CONCAT(big_boss.first_name, ' ', big_boss.last_name), 'No Manager') AS manager_name
         FROM employee AS worker_bee
         LEFT JOIN department AS dept_den ON worker_bee.dept_id = dept_den.dept_id
         LEFT JOIN employee AS big_boss ON worker_bee.manager_id = big_boss.emp_id
         ORDER BY worker_bee.emp_id
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
