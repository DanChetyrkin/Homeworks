import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: DENSE_RANK inside a CTE (no gaps, ties share a rank),
    # the outer query keeps ranks 1 and 2
    cursor.execute("""
         WITH kiwi AS (
             SELECT donut.name AS department,
                    tiger.emp_id,
                    tiger.first_name,
                    tiger.last_name,
                    tiger.monthly_salary,
                    DENSE_RANK() OVER (PARTITION BY tiger.dept_id ORDER BY tiger.monthly_salary DESC) AS salary_rank
             FROM employee AS tiger
             JOIN department AS donut ON tiger.dept_id = donut.dept_id
         )
         SELECT department, emp_id, first_name, last_name, monthly_salary, salary_rank
         FROM kiwi
         WHERE salary_rank <= 2
         ORDER BY department, salary_rank, emp_id
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
