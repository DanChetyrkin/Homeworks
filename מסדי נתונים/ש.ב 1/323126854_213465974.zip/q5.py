import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: DENSE_RANK inside a CTE (no gaps, ties share a rank),
    # the outer query keeps ranks 1 and 2
    cursor.execute("""
         WITH salary_podium AS (
             SELECT dept_den.name AS department,
                    worker_bee.emp_id,
                    worker_bee.first_name,
                    worker_bee.last_name,
                    worker_bee.monthly_salary,
                    DENSE_RANK() OVER (PARTITION BY worker_bee.dept_id ORDER BY worker_bee.monthly_salary DESC) AS salary_rank
             FROM employee AS worker_bee
             JOIN department AS dept_den ON worker_bee.dept_id = dept_den.dept_id
         )
         SELECT department, emp_id, first_name, last_name, monthly_salary, salary_rank
         FROM salary_podium
         WHERE salary_rank <= 2
         ORDER BY department, salary_rank, emp_id
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
