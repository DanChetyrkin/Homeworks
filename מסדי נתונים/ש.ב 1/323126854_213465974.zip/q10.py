import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: total cost per customer in a CTE (customers with usage only),
    # then keep those above the average of these totals
    cursor.execute("""
         WITH customer_tabs AS (
             SELECT paying_pal.company_name,
                    paying_pal.tier,
                    SUM(token_munch.tokens / 1000 * brainy_bot.price_per_1k_tokens) AS total_cost
             FROM customer AS paying_pal
             JOIN api_usage AS token_munch ON paying_pal.customer_id = token_munch.customer_id
             JOIN ai_model AS brainy_bot ON token_munch.model_id = brainy_bot.model_id
             GROUP BY paying_pal.customer_id, paying_pal.company_name, paying_pal.tier
         )
         SELECT company_name, tier, total_cost
         FROM customer_tabs
         WHERE total_cost > (SELECT AVG(total_cost) FROM customer_tabs)
         ORDER BY total_cost DESC
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
