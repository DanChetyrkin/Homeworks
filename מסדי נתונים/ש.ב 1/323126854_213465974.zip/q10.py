import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: total cost per customer in a CTE (customers with usage only),
    # then keep those above the average of these totals
    cursor.execute("""
         WITH burrito AS (
             SELECT pickle.company_name,
                    pickle.tier,
                    SUM(zebra.tokens / 1000 * llama.price_per_1k_tokens) AS total_cost
             FROM customer AS pickle
             JOIN api_usage AS zebra ON pickle.customer_id = zebra.customer_id
             JOIN ai_model AS llama ON zebra.model_id = llama.model_id
             GROUP BY pickle.customer_id, pickle.company_name, pickle.tier
         )
         SELECT company_name, tier, total_cost
         FROM burrito
         WHERE total_cost > (SELECT AVG(total_cost) FROM burrito)
         ORDER BY total_cost DESC
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
