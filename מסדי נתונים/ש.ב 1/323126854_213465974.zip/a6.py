import mysql.connector

if __name__ == '__main__':
    # connect to the server
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the statements
    cursor = mydb.cursor()
    statements = [
        # (a) 8% raise for the Research department
        """
        UPDATE employee
        SET monthly_salary = monthly_salary * 1.08
        WHERE dept_id IN (SELECT dept_id
                          FROM department
                          WHERE name = 'Research')
        """,
        # (b) customers with at least 1,000,000 tokens become Enterprise
        """
        UPDATE customer
        SET tier = 'Enterprise'
        WHERE customer_id IN (SELECT customer_id
                              FROM api_usage
                              GROUP BY customer_id
                              HAVING SUM(tokens) >= 1000000)
        """,
        # (c) customers with 200,000 up to 1,000,000 tokens become Pro
        """
        UPDATE customer
        SET tier = 'Pro'
        WHERE customer_id IN (SELECT customer_id
                              FROM api_usage
                              GROUP BY customer_id
                              HAVING SUM(tokens) >= 200000
                                 AND SUM(tokens) < 1000000)
        """,
        # (d) Israeli customers without a manager get employee 15
        """
        UPDATE customer
        SET account_manager_id = 15
        WHERE country = 'Israel'
          AND account_manager_id IS NULL
        """,
        # (d) customers from outside Israel get employee 16
        """
        UPDATE customer
        SET account_manager_id = 16
        WHERE country <> 'Israel' 
        """,
        # (e) X-Ray Triage ended
        """
        UPDATE project
        SET end_date = '2026-10-31'
        WHERE project_name = 'X-Ray Triage' 
        """,
        # (f) BarVision-Lite release date and new lead engineer
        """
        UPDATE ai_model
        SET release_date = '2026-11-10', lead_engineer_id = 19
        WHERE model_name = 'BarVision-Lite' 
        """,
    ]
    # run every statement in order and print rows when there are any
    for statement in statements:
        cursor.execute(statement)
        if cursor.with_rows:
            print(cursor.fetchall())
    # save the changes and close
    mydb.commit()
    cursor.close()
    mydb.close()
