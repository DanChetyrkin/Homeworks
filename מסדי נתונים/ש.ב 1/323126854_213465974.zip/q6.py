import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: LAG per customer ordered by date, the first record has no previous so it is NULL
    cursor.execute("""
         SELECT pickle.company_name,
                zebra.usage_date,
                zebra.tokens,
                zebra.tokens - LAG(zebra.tokens) OVER (PARTITION BY zebra.customer_id ORDER BY zebra.usage_date) AS tokens_change
         FROM api_usage AS zebra
         JOIN customer AS pickle ON zebra.customer_id = pickle.customer_id
         ORDER BY pickle.company_name, zebra.usage_date
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
