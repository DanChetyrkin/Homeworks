import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: LAG per customer ordered by date, the first record has no previous so it is NULL
    cursor.execute("""
         SELECT paying_pal.company_name,
                token_munch.usage_date,
                token_munch.tokens,
                token_munch.tokens - LAG(token_munch.tokens) OVER (PARTITION BY token_munch.customer_id ORDER BY token_munch.usage_date) AS tokens_change
         FROM api_usage AS token_munch
         JOIN customer AS paying_pal ON token_munch.customer_id = paying_pal.customer_id
         ORDER BY paying_pal.company_name, token_munch.usage_date
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
