import mysql.connector

if __name__ == '__main__':
    # connect to the server
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the statements
    cursor = mydb.cursor()
    statements = [
        # (a) department table
        """
        CREATE TABLE department (
            dept_id INT PRIMARY KEY,
            name VARCHAR(50) NOT NULL UNIQUE,
            budget DECIMAL(12,2) NOT NULL CHECK (budget >= 0),
            location VARCHAR(50) DEFAULT 'Ramat Gan'
        )
        """,
        # (b) employee table, with a self reference for the manager
        """
        CREATE TABLE employee (
            emp_id INT PRIMARY KEY,
            first_name VARCHAR(30) NOT NULL,
            last_name VARCHAR(30) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            hire_date DATE NOT NULL,
            salary DECIMAL(10,2) NOT NULL,
            dept_id INT,
            manager_id INT,
            FOREIGN KEY (dept_id) REFERENCES department(dept_id)
                ON DELETE SET NULL ON UPDATE CASCADE,
            FOREIGN KEY (manager_id) REFERENCES employee(emp_id)
                ON DELETE SET NULL
        )
        """,
        # (c) customer table
        """
        CREATE TABLE customer (
            customer_id INT PRIMARY KEY,
            company_name VARCHAR(100) NOT NULL UNIQUE,
            country VARCHAR(50) NOT NULL,
            industry VARCHAR(50),
            joined_date DATE NOT NULL
        )
        """,
        # (d) model_type lookup table
        """
        CREATE TABLE model_type (
            type_name VARCHAR(20) PRIMARY KEY,
            description VARCHAR(100) NOT NULL
        )
        """,
        # (e) ai_model table
        """
        CREATE TABLE ai_model (
            model_id INT PRIMARY KEY,
            model_name VARCHAR(20) NOT NULL UNIQUE,
            model_type VARCHAR(20) NOT NULL,
            release_date DATE,
            price_per_1k_tokens DECIMAL(6,4) NOT NULL,
            lead_engineer_id INT,
            FOREIGN KEY (model_type) REFERENCES model_type(type_name),
            FOREIGN KEY (lead_engineer_id) REFERENCES employee(emp_id)
        )
        """,
        # (f) project table
        """
        CREATE TABLE project (
            project_id INT PRIMARY KEY,
            project_name VARCHAR(100) NOT NULL,
            customer_id INT NOT NULL,
            dept_id INT NOT NULL,
            model_id INT,
            start_date DATE NOT NULL,
            end_date DATE,
            budget DECIMAL(12,2) NOT NULL,
            FOREIGN KEY (customer_id) REFERENCES customer(customer_id)
                ON DELETE CASCADE,
            FOREIGN KEY (dept_id) REFERENCES department(dept_id)
                ON DELETE RESTRICT ON UPDATE CASCADE,
            FOREIGN KEY (model_id) REFERENCES ai_model(model_id)
                ON DELETE SET NULL,
            CHECK (end_date IS NULL OR end_date >= start_date)
        )
        """,
        # (g) assignment table, many-to-many between employee and project
        """
        CREATE TABLE assignment (
            emp_id INT,
            project_id INT,
            role VARCHAR(30) NOT NULL,
            hours_per_week INT DEFAULT 10 CHECK (hours_per_week BETWEEN 1 AND 40),
            PRIMARY KEY (emp_id, project_id),
            FOREIGN KEY (emp_id) REFERENCES employee(emp_id)
                ON DELETE CASCADE,
            FOREIGN KEY (project_id) REFERENCES project(project_id)
                ON DELETE CASCADE
        )
        """,
    ]
    # run every statement in order and print rows when there are any
    for statement in statements:
        cursor.execute(statement)
        if cursor.with_rows:
            print(cursor.fetchall())
    # save the changes and close
    mydb.commit()
    cursor.close()
    mydb.close()
