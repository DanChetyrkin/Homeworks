import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: left join keeps unused models, COALESCE turns the NULL sum into 0
    cursor.execute("""
         SELECT llama.model_name,
                llama.model_type,
                COUNT(zebra.usage_id) AS num_records,
                COALESCE(SUM(zebra.tokens), 0) AS total_tokens
         FROM ai_model AS llama
         LEFT JOIN api_usage AS zebra ON llama.model_id = zebra.model_id
         GROUP BY llama.model_id, llama.model_name, llama.model_type
         ORDER BY total_tokens DESC, llama.model_name
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
