import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: left join keeps unused models, COALESCE turns the NULL sum into 0
    cursor.execute("""
         SELECT brainy_bot.model_name,
                brainy_bot.model_type,
                COUNT(token_munch.usage_id) AS num_records,
                COALESCE(SUM(token_munch.tokens), 0) AS total_tokens
         FROM ai_model AS brainy_bot
         LEFT JOIN api_usage AS token_munch ON brainy_bot.model_id = token_munch.model_id
         GROUP BY brainy_bot.model_id, brainy_bot.model_name, brainy_bot.model_type
         ORDER BY total_tokens DESC, brainy_bot.model_name
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
