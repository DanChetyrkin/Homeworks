import mysql.connector

if __name__ == '__main__':
    # connect to the server
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the statements
    cursor = mydb.cursor()
    statements = [
        # (a) two new employees
        """
        INSERT INTO employee (emp_id, first_name, last_name, email, hire_date, monthly_salary, dept_id, manager_id) VALUES
            (21, 'Noam', 'Biton', 'noam.biton@bar-ai.com', '2026-11-01', 17000, 1, 2),
            (22, 'Rotem', 'Hadad', 'rotem.hadad@bar-ai.com', '2026-11-01', 11000, 4, 5)
        """,
        # (b) new model with the long name
        """
        INSERT INTO ai_model (model_id, model_name, model_type, release_date, price_per_1k_tokens, lead_engineer_id)
        VALUES (8, 'BarGPT-3 Reasoning Ultra', 'LLM', '2026-11-01', 0.0800, 2)
        """,
        # (c) new customer
        """
        INSERT INTO customer (customer_id, company_name, country, industry, joined_date, tier, account_manager_id)
        VALUES (11, 'Carmel Robotics', 'Israel', 'Robotics', '2026-11-01', 'Pro', 15)
        """,
        # (d) new project
        """
        INSERT INTO project (project_id, project_name, customer_id, dept_id, model_id, start_date, end_date, budget)
        VALUES (12, 'Warehouse Robot Planner', 11, 1, 8, '2026-11-01', NULL, 200000)
        """,
        # (e) assignment without hours, so the default of 10 is used
        """
        INSERT INTO assignment (emp_id, project_id, role)
        VALUES (21, 12, 'Researcher')
        """,
        # (e) assignment with 5 hours
        """
        INSERT INTO assignment (emp_id, project_id, role, hours_per_week)
        VALUES (2, 12, 'Tech Lead', 5)
        """,
        # (f) usage record, usage_id comes from AUTO_INCREMENT
        """
        INSERT INTO api_usage (customer_id, model_id, usage_date, tokens)
        VALUES (11, 8, '2026-11-05', 40000)
        """,
    ]
    # run every statement in order and print rows when there are any
    for statement in statements:
        cursor.execute(statement)
        if cursor.with_rows:
            print(cursor.fetchall())
    # save the changes and close
    mydb.commit()
    cursor.close()
    mydb.close()
