import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: total project budget per department in a CTE,
    # then keep the departments equal to the maximum (ties stay)
    cursor.execute("""
         WITH dept_wallets AS (
             SELECT dept_den.name AS department,
                    SUM(grand_plan.budget) AS total_budget
             FROM department AS dept_den
             JOIN project AS grand_plan ON dept_den.dept_id = grand_plan.dept_id
             GROUP BY dept_den.dept_id, dept_den.name
         )
         SELECT department, total_budget
         FROM dept_wallets
         WHERE total_budget = (SELECT MAX(total_budget) FROM dept_wallets)
         ORDER BY department
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
