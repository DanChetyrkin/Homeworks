import mysql.connector

if __name__ == '__main__':
    # connect to the bar_ai database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="bar_ai",
        port="3307",
    )

    # cursor that runs the query
    cursor = mydb.cursor()
    # query: total project budget per department in a CTE,
    # then keep the departments equal to the maximum (ties stay)
    cursor.execute("""
         WITH potato AS (
             SELECT donut.name AS department,
                    SUM(waffle.budget) AS total_budget
             FROM department AS donut
             JOIN project AS waffle ON donut.dept_id = waffle.dept_id
             GROUP BY donut.dept_id, donut.name
         )
         SELECT department, total_budget
         FROM potato
         WHERE total_budget = (SELECT MAX(total_budget) FROM potato)
         ORDER BY department
    """)
    # print the rows of the result
    print(', '.join(str(row) for row in cursor.fetchall()))
    cursor.close()
    mydb.close()
