
import mysql.connector

if __name__ == '__main__':
    # connect to the sakila database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="sakila",
        port="3307",
    )

    cursor = mydb.cursor()

    # join the tables to get films and their categories
    # count the films and find the average length for each category and keep categories with at least 60 films and average length above 110
    # sort by average length from high to low
    cursor.execute("""
        select category.name as category,
               count(*) as num_films,
               avg(film.length) as avg_length
        from category
        join film_category
            on category.category_id = film_category.category_id
        join film
            on film_category.film_id = film.film_id
        group by category.category_id, category.name
        having count(*) >= 60
           and avg(film.length) > 110
        order by avg_length desc
    """)

    # print the results
    print(', '.join(str(row) for row in cursor.fetchall()))

    # close the connection
    cursor.close()
    mydb.close()
