import mysql.connector

if __name__ == '__main__':
    #connect to the sakila database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="sakila",
        port="3307",
    )

    cursor = mydb.cursor()

    # find pg-13 films between 100 and 120 minutes and only include films with a rental price below 3
    # then sort by length from high to low, then by title
    cursor.execute("""
        select title, rating, length, replacement_cost
        from film
        where rating = 'PG-13'
          and length between 100 and 120
          and rental_rate < 3.00
        order by length desc, title asc
    """)

    #print all matching films
    print(', '.join(str(row) for row in cursor.fetchall()))

    #close the connection
    cursor.close()
    mydb.close()