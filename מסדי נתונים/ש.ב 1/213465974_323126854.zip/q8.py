
import mysql.connector

if __name__ == '__main__':
    # connect to the sakila database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="sakila",
        port="3307",
    )

    cursor = mydb.cursor()

    # find actors and customers with last names starting with wil, combine both lists and remove duplicate names, sort by last name and then by first name
    cursor.execute("""
        select first_name, last_name
        from actor
        where last_name like 'WIL%'

        union

        select first_name, last_name
        from customer
        where last_name like 'WIL%'

        order by last_name asc, first_name asc
    """)

    #print all matching names
    print(', '.join(str(row) for row in cursor.fetchall()))

    #close the connection
    cursor.close()
    mydb.close()
