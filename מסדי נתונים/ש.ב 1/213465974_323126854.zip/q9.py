
import mysql.connector

if __name__ == '__main__':
    # connect to the sakila database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="sakila",
        port="3307",
    )

    cursor = mydb.cursor()

    # find customers who rented a horror film rated nc-17
    # and also rented a music film rated g
    # both conditions must be true for the same customer
    cursor.execute("""
        select customer.customer_id,
               customer.first_name,
               customer.last_name
        from customer
        where exists (
            select 1
            from rental
            join inventory
                on rental.inventory_id = inventory.inventory_id
            join film
                on inventory.film_id = film.film_id
            join film_category
                on film.film_id = film_category.film_id
            join category
                on film_category.category_id = category.category_id
            where rental.customer_id = customer.customer_id
              and category.name = 'Horror'
              and film.rating = 'NC-17'
        )
        and exists (
            select 1
            from rental
            join inventory
                on rental.inventory_id = inventory.inventory_id
            join film
                on inventory.film_id = film.film_id
            join film_category
                on film.film_id = film_category.film_id
            join category
                on film_category.category_id = category.category_id
            where rental.customer_id = customer.customer_id
              and category.name = 'Music'
              and film.rating = 'G'
        )
        order by customer.customer_id asc
    """)

    # print all matching customers
    print(', '.join(str(row) for row in cursor.fetchall()))

    # close the connection
    cursor.close()
    mydb.close()
