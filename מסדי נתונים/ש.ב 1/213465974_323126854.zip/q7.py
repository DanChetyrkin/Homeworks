
import mysql.connector

if __name__ == '__main__':
    #connect to the sakila database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="sakila",
        port="3307",
    )

    cursor = mydb.cursor()

    #find pairs of actors who played in the same films and then
    #use actor ids to show each pair only once, count shared films and keep pairs with at least 5,sort by shared films, then by actor names
    cursor.execute("""
        select concat(a1.first_name, ' ', a1.last_name) as actor1,
               concat(a2.first_name, ' ', a2.last_name) as actor2,
               count(*) as shared_films
        from film_actor as fa1
        join film_actor as fa2
            on fa1.film_id = fa2.film_id
           and fa1.actor_id < fa2.actor_id
        join actor as a1
            on fa1.actor_id = a1.actor_id
        join actor as a2
            on fa2.actor_id = a2.actor_id
        group by a1.actor_id, a1.first_name, a1.last_name,
                 a2.actor_id, a2.first_name, a2.last_name
        having count(*) >= 5
        order by shared_films desc, actor1 asc, actor2 asc
    """)

    # print all matching actor pairs
    print(', '.join(str(row) for row in cursor.fetchall()))

    #close the connection
    cursor.close()
    mydb.close()
