
import mysql.connector

if __name__ == '__main__':
    #connect to the sakila database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="sakila",
        port="3307",
    )

    cursor = mydb.cursor()

    #find actors who played in at least one action film, remove actors who played in any drama film, sort by last name, first name and actor id
    cursor.execute("""
        select actor.actor_id,
               actor.first_name,
               actor.last_name
        from actor
        where exists (
            select 1
            from film_actor
            join film_category
                on film_actor.film_id = film_category.film_id
            join category
                on film_category.category_id = category.category_id
            where film_actor.actor_id = actor.actor_id
              and category.name = 'Action'
        )
        and not exists (
            select 1
            from film_actor
            join film_category
                on film_actor.film_id = film_category.film_id
            join category
                on film_category.category_id = category.category_id
            where film_actor.actor_id = actor.actor_id
              and category.name = 'Drama'
        )
        order by actor.last_name asc,
                 actor.first_name asc,
                 actor.actor_id asc
    """)

    #print all matching actors
    print(', '.join(str(row) for row in cursor.fetchall()))

    #close the connection
    cursor.close()
    mydb.close()
