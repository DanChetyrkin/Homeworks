
import mysql.connector

if __name__ == '__main__':
    # connect to the sakila database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="sakila",
        port="3307",
    )

    cursor = mydb.cursor()

    # join customers with their payments and count payments and calculate the total paid by each customer
    # keep customers with at least 35 payments and a total of 175 or more, sort by number of payments, then by customer id
    cursor.execute("""
        select customer.customer_id,
               customer.first_name,
               customer.last_name,
               count(payment.payment_id) as num_payments,
               sum(payment.amount) as total_paid
        from customer
        join payment
            on customer.customer_id = payment.customer_id
        group by customer.customer_id,
                 customer.first_name,
                 customer.last_name
        having count(payment.payment_id) >= 35
           and sum(payment.amount) >= 175
        order by num_payments desc, customer.customer_id asc
    """)

    # print the results
    print(', '.join(str(row) for row in cursor.fetchall()))

    # close the connection
    cursor.close()
    mydb.close()
