import mysql.connector

if __name__ == '__main__':
    # connect to the sakila database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="sakila",
        port="3307",
    )

    cursor = mydb.cursor()

    # find active customers with four letters in their first name
    # the second letter must be a
    # remove duplicate names and sort them by name
    cursor.execute("""
        select distinct first_name
        from customer
        where active = 1
          and first_name like '_A__'
        order by first_name asc
    """)

    # print all matching names
    print(', '.join(str(row) for row in cursor.fetchall()))

    # close the connection
    cursor.close()
    mydb.close()