
import mysql.connector

if __name__ == '__main__':
    # connect to the sakila database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="sakila",
        port="3307",
    )

    cursor = mydb.cursor()

    # find films with documentary in the description and commentaries in their special features
    # count the films and calculate average length and find the lowest and highest replacement cost
    cursor.execute("""
        select count(*) as num_films,
               avg(length) as avg_length,
               min(replacement_cost) as min_cost,
               max(replacement_cost) as max_cost
        from film
        where description like '%Documentary%'
          and special_features like '%Commentaries%'
    """)

    # print the results
    print(', '.join(str(row) for row in cursor.fetchall()))

    # close the connection
    cursor.close()
    mydb.close()
