
import mysql.connector

if __name__ == '__main__':
    #connect to the sakila database
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="sakila",
        port="3307",
    )

    cursor = mydb.cursor()

    # compare films from the same table and find pairs with the same length, rental rate, cost and rating
    # show each pair only once, with titles in alphabetical order
    cursor.execute("""
        select f1.title as title1,
               f2.title as title2,
               f1.length,
               f1.rental_rate,
               f1.replacement_cost,
               f1.rating
        from film as f1
        join film as f2
            on f1.length = f2.length
           and f1.rental_rate = f2.rental_rate
           and f1.replacement_cost = f2.replacement_cost
           and f1.rating = f2.rating
        where f1.title < f2.title
           or (f1.title = f2.title and f1.film_id < f2.film_id)
        order by title1 asc
    """)

    #print all matching film pairs
    print(', '.join(str(row) for row in cursor.fetchall()))

    #close the connection
    cursor.close()
    mydb.close()
